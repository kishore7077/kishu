
import UIKit
import FacebookCore
import FacebookLogin

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func actionLogin(_ sender: Any) {
        
        let manager = LoginManager()
        manager.logIn(permissions: [.publicProfile, .email], viewController: self) { (result) in
            switch result {
            case.cancelled:
                print("User Cancelled")
                break
                
            case .success(let grantedPermissions,  let declinedPermissions,  let accessToken):
                print("acessToken == \(accessToken) ")
                break
                
                
            case .failed(let error ):
                print("Login Failed with error = \(error.localizedDescription )")
                break
                    
                    
                
                }
            }
            
        }
    }
    


